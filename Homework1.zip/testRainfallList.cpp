#include "RainfallList.h"
#include <iostream>
#include <cassert>
#include <string>
using namespace std;

void test()
{
    RainfallList s;
    s.add(400);
    s.add(500);
    s.add(300);
    s.add(0);
    s.add(60);
    s.add(50);
    s.add(70);
    assert(s.size() == 6);
    s.remove(400);
    s.remove(0);
    assert(s.minimum() == 50);
    assert(s.maximum() == 300);
}

int main() {
    test();
    cout << "passed all tests." << endl;
}