#include "RainfallList.h"
RainfallList::RainfallList() {
	m_numvalues = 0;
}      
// Create an empty rainfall list.

bool RainfallList::add(unsigned long rainfall) {
	if (rainfall <= 400 && rainlist.size() < DEFAULT_MAX_ITEMS) {
		rainlist.insert(rainfall);
		m_numvalues++;
		return true;
	}
		return false;
}
// If the rainfall is valid (a value from 0 to 400) and the rainfall list
// has room for it, add it to the rainfall list and return true.
// Otherwise, leave the rainfall list unchanged and return false.

bool RainfallList::remove(unsigned long rainfall) {
	if (rainfall <= 400 && rainlist.size() > 0 && rainlist.size() <= DEFAULT_MAX_ITEMS) {
		int pos = rainlist.find(rainfall);
		if (pos != -1) {
			rainlist.erase(pos);
			m_numvalues--;
			return true;
		}
	}
	return false;
}
// Remove one instance of the specified rainfall from the rainfall list.
// Return true if a rainfall was removed; otherwise false.

int RainfallList::size() const {
	return m_numvalues;
}// Return the number of rainfalls in the list.

unsigned long RainfallList::minimum() const {
	if (size() > 0) {
		ItemType lower = 400;
		ItemType measurement;
		for (int i = 0; i < size(); i++) {
			rainlist.get(i, measurement);
			lower = ((lower>=measurement)?measurement:lower);
			}
		return lower;
		}
	return NO_RAINFALLS;
}
// Return the lowest-valued rainfall in the rainfall list.  If the list is
// empty, return NO_RAINFALLS.

unsigned long RainfallList::maximum() const {
	if (size() > 0) {
		ItemType larger = 0;
		ItemType measurement;
		for (int i = 0; i < size(); i++) {
			rainlist.get(i, measurement);
			larger = ((larger <= measurement)?measurement:larger);
		}
		return larger;
	}
	return NO_RAINFALLS;
}
// Return the highest-valued rainfall in the rainfall list.  If the list is
// empty, return NO_RAINFALLS.
