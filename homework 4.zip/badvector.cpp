void removeBad(vector<Restaurant*>& v)
{
	for (vector<Restaurant*>::iterator it = v.begin(); it != v.end(); it++) {
		if ((*it)->stars() <= 2)
		{
			delete* it;
			it = v.erase(it);
			it--;
		}
	}
}