void listAll(const MenuItem* m, string path) // two-parameter overload
{
    if (!path.empty())
        path += "/";
    path += m->name();
    cout << path << endl;

    const vector<MenuItem*>* submenus = m->menuItems();
    if (submenus != nullptr)
    {
        for (size_t k = 0; k < submenus->size(); k++)
            listAll((*submenus)[k], path);
    }
}
