void removeEven(list<int>& li)
{
	for (list<int>::iterator it = li.begin(); it != li.end(); it++) 
	{
		if ((*it % 2) == 0)
		{
			it = li.erase(it);
			it--;
		}
	}
}