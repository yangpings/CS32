void removeBad(list<Restaurant*>& li)
{
	for (list<Restaurant*>::iterator it = li.begin(); it != li.end(); it++) {
		if ((*it)->stars() <=2)
		{
 			delete * it;
			it = li.erase(it);
			it--;
		}
	}
}