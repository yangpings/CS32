#ifndef SEQUENCE_H
#define SEQUENCE_H
//#include<string>
//using ItemType = std::string;

using ItemType = unsigned long;


const int DEFAULT_MAX_ITEMS = 160;

class Sequence
{
public:
    Sequence(); 
    bool empty() const; 
    int size() const; 
    int insert(int pos, const ItemType& value);
    int insert(const ItemType& value);
    bool erase(int pos);
    int remove(const ItemType& value);
    bool get(int pos, ItemType& value) const;
    bool set(int pos, const ItemType& value);
    int find(const ItemType& value) const;
    void swap(Sequence& other);

    ~Sequence();
    Sequence(const Sequence& other);
    Sequence& operator = (const Sequence& other);

private:
    struct Node {
        Node(ItemType value, Node* prev = nullptr, Node* next = nullptr);
        ItemType value;
        Node* next;
        Node* prev;
    };
    Node* head;
    Node* del_head();
    Node* del_node(Node* node);
    void resetseq();
    void fillseq(const Sequence& other);
    int   m_size;                     // number of items in the sequence
};
int subsequence(const Sequence& seq1, const Sequence& seq2);
void concatReverse(const Sequence& seq1, const Sequence& seq2, Sequence& result);

#endif 