#include "Sequence.h"
#include <iostream>

Sequence::Node::Node(ItemType value, Node* prev, Node* next) {
    this->value = value;
    this->next = next;
    this->prev = prev;
}

Sequence::Node* Sequence::del_head() {
    Node* newhead = head->next;
    if (newhead != nullptr) {
        newhead->prev = nullptr;
    }
    delete head;
    head = newhead;
    m_size--;
    return newhead;
}

Sequence::Node* Sequence::del_node(Node* node) {
    Node* nextnode = node->next;
    Node* prevnode = node->prev;
    if (prevnode != nullptr) {
        prevnode->next = nextnode;
    }
    if (nextnode != nullptr) {
        nextnode->prev = prevnode;
    }
    delete node;
    m_size--;
    return nextnode;
}

void Sequence::resetseq() {
    if (m_size > 0) {
        Node* nodep = head;
        while (nodep != nullptr) {
            Node* nextnodep = nodep->next;
            delete nodep;
            nodep = nextnodep;
        }
    }
    m_size = 0;
}

void Sequence::fillseq(const Sequence& other) {
    ItemType newvalue;
    m_size = 0;
    head = nullptr;
    if (other.m_size > 0) {
        for (int i = 0; i < other.m_size; i++) {
            other.get(i, newvalue);
            insert(i, newvalue);
        }
    }
}

Sequence::Sequence() {
    head = nullptr;
    m_size = 0;
}

bool Sequence::empty() const {
    if (m_size == 0){
    return true;
    }
    return false;
}

int Sequence::size() const {
    return m_size;
}

int Sequence::insert(int pos, const ItemType& value)
{
    if (pos < 0 || pos > m_size) {
        return -1;
    }

    if (pos == 0){
        Node* oldheadPtr = head;
        head = new Node(value, nullptr, oldheadPtr);
        if (oldheadPtr != nullptr)
            oldheadPtr->prev = head;
        m_size++;
        return 0;
    }

    Node* nodepm1 = head;
    for (int i = 0; i < pos - 1; i++){
        nodepm1 = nodepm1->next;
    }

    Node* nodep = nodepm1->next;
    nodepm1->next = new Node(value, nodepm1, nodep);
    if (nodep != nullptr)
        nodep->prev = nodepm1->next;
    m_size++;
    return pos;
}

int Sequence::insert(const ItemType& value)
{
    int p;
    Node* nodei = head;
    for (p = 0; p < m_size; p++){
        if (value <= nodei->value)
            break;
        nodei = nodei->next;
    }
    return this->insert(p, value);
}

bool Sequence::erase(int pos)
{
    if (pos < 0 || pos >= size())
        return false;
    if (pos == 0) {
        this->del_head();
        return true;
    }
    else {
        Node* p = head;
        for (int i = 0; i < pos; i++) {
            p = p->next;
        }
        this->del_node(p);
        return true;
    }
}

int Sequence::remove(const ItemType& value)
{
    int count = 0, i = 0;
    Node* nodep = head;
    while (i < m_size) {
        if (nodep->value == value) {
            count++;
            if (i == 0) {
                nodep = this -> del_head();
            }
            else {
                nodep = this->del_node(nodep);
            }
        }
        else {
            i++;
            nodep = nodep->next;
        }
    }
    return count;
}

bool Sequence::get(int pos, ItemType& value) const
{
    if (pos < 0 || pos >= size())
        return false;
    Node* nodep = head;
    for (int i = 0; i < pos; i++) {
        nodep = nodep->next;
    }
    value = nodep->value;
    return true;
}

bool Sequence::set(int pos, const ItemType& value)
{
    if (pos < 0 || pos >= size())
        return false;
    Node* nodep = head;
    for (int i = 0; i < pos; i++) {
        nodep = nodep->next;
    }
    nodep->value = value;
    return true;
}

int Sequence::find(const ItemType& value) const
{
    Node* nodep = head;
    for (int i = 0; i < m_size; i++) {
        if (nodep->value == value) {
            return i;
        }
        nodep = nodep->next;
    }
    return -1;
}

void Sequence::swap(Sequence& other)
{
    Node* head_temp = this->head;
    int m_size_temp = this->m_size;
    head = other.head;
    m_size = other.m_size;
    other.head = head_temp;
    other.m_size = m_size_temp;
}

Sequence::~Sequence() {
    this->resetseq();
}

Sequence::Sequence(const Sequence& other) {
    this->fillseq(other);
}
Sequence& Sequence::operator = (const Sequence& other) {
    if (this == &other) {
        return *this;
    }
    this->resetseq();
    this->fillseq(other);
    return *this;
}

int subsequence(const Sequence& seq1, const Sequence& seq2) {
    int size_seq1 = seq1.size();
    int size_seq2 = seq2.size();
    if (size_seq1 == 0 || size_seq2 == 0) {
        return -1;
    }
    ItemType item_seq1, item_seq2;
    for (int i = 0; i <= (size_seq1 - size_seq2); i++) {
        seq1.get(i, item_seq1);
        seq2.get(0, item_seq2);
        if (item_seq1 == item_seq2) {
            int j, k;
            for (j = i + 1, k = 1; k < size_seq2; j++, k++) {
                seq1.get(j, item_seq1);
                seq2.get(k, item_seq2);
                if (item_seq1 != item_seq2) {
                    break;
                }
            }
            if (k == size_seq2) {
                return i;
            }
        }

    }
    return -1;

}
void concatReverse(const Sequence& seq1, const Sequence& seq2, Sequence& result) {
    Sequence combinereverse;
    const int size_seq1 = seq1.size(), size_seq2 = seq2.size();
    ItemType value;

    if (size_seq1 > 0)
        for (int i = 0; i < size_seq1; i++) {
            seq1.get(i, value);
            combinereverse.insert(0, value);
        }
    if (size_seq2 > 0)
        for (int i = 0; i < size_seq2; i++) {
            seq2.get(i, value);
            combinereverse.insert(size_seq1, value);
        }
    result = combinereverse;
}



