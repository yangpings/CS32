class Event
{
public:
    Event(const string name) : m_name(name) 
    {}
    virtual string name() const 
    {
        return m_name; 
    }
    virtual bool isSport() const 
    {
        return true; 
    }
    virtual string need() const = 0; 
    virtual ~Event() 
    {}
private:
    string m_name;
};

class BasketballGame : public Event
{
public:
    BasketballGame(string name) : Event(name)
    {}
    string need() const
    { 
        return "hoops"; 
    }
    ~BasketballGame()
    {
        cout << "Destroying the " << this->name() << " basketball game" << endl;
    }
};

class Concert : public Event
{
public:
    Concert(string name1, string name2) : Event(name1), m_name2(name2)
    {}
    bool isSport() const
    {
        return false; 
    }
    string need() const
    {
        return "a stage"; 
    }
    ~Concert()
    {
        cout << "Destroying the " << this->name() + ' ' + m_name2 << " concert" << endl;
    }
private:
    string m_name2;
};

class HockeyGame : public Event
{
public:
    HockeyGame(string name) : Event(name)
    {}
    string need() const
    { 
        return "ice"; 
    }
    ~HockeyGame()
    {
        cout << "Destroying the " << this->name() << " hockey game" << endl;
    }
};