bool allTrue(const string a[], int n)
{
    if (n <= 0) return true;
    return somePredicate(a[0]) && allTrue(a + 1, n - 1);
}

int countTrue(const string a[], int n)
{
    if (n <= 0) return 0;
    if (somePredicate(a[0]))
        return 1 + countTrue(a + 1, n - 1);
    else
        return countTrue(a + 1, n - 1);
}

int firstTrue(const string a[], int n)
{
    if (n <= 0) return -1;
    if (somePredicate(a[0])) return 0;
    int i = firstTrue(a + 1, n - 1);
    return (i == -1) ? -1 : i + 1;
}

int positionOfMax(const string a[], int n)
{
    if (n <= 0) return -1;
    if (n == 1) return 0;
    return (a[0] >= a[n - 1]) ? positionOfMax(a, n - 1) : 1 + positionOfMax(a + 1, n - 1);
}


bool contains(const string a1[], int n1, const string a2[], int n2)
{
    if (n2 <= 0) return true;
    else if (n1 <= 0) return false;
    if (a1[0] == a2[0])
        return contains(a1 + 1, n1 - 1, a2 + 1, n2 - 1);
    else
        return contains(a1 + 1, n1 - 1, a2, n2);
}