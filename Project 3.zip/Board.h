#ifndef Board_H
#define Board_H
#include "Side.h"

class Board {
public:
	Board(int nHoles, int nInitialBeansPerHole); // constructor
	int holes() const;
	int beans(Side s, int hole) const;
	int beansInPlay(Side s) const;
	int totalBeans() const;
	bool sow(Side s, int hole, Side & endSide, int& endHole);
	bool moveToPot(Side s, int hole, Side potOwner);
	bool setBeans(Side s, int hole, int beans);
	~Board(); //Destructor
	Board(const Board& other); //copy constructor
	Board& operator=(const Board& rhs); //assignment operator

private:
	int m_nholes;
	int m_nbeans;
	int m_nholesOnASide;
	int m_nbeansNorthPot;
	int* m_nbeansNorthHole;
	int m_nbeansSouthPot;
	int* m_nbeansSouthHole;
};


#endif