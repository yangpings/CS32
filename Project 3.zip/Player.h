#ifndef Player_H
#define Player_H
#include "Board.h"
#include <iostream>

class Player { // abstract class
public:
	Player(std::string name);
	std::string name() const;
	virtual bool isInteractive() const; // virtual function
	virtual int chooseMove(const Board& b, Side s) const = 0;
	virtual ~Player(); // virtual constructor
private:
	std::string m_name;
};

class HumanPlayer : public Player { // derived class
public:
	HumanPlayer(std::string name);
	bool isInteractive() const;
	int chooseMove(const Board& b, Side s) const;
	~HumanPlayer();
};

class BadPlayer : public Player { // derived class
public:
	BadPlayer(std::string name);
	bool isInteractive() const;
	int chooseMove(const Board& b, Side s) const;
	~BadPlayer();
};

class SmartPlayer : public Player { // derived class
public:
	SmartPlayer(std::string name);
	bool isInteractive() const;
	int chooseMove(const Board& b, Side s) const;
	~SmartPlayer();
private:
	void m_chooseMove(Side s, const Board& b, int & bestHole, int & value, int depth, clock_t t) const;
	bool m_move(Side s, Board& b, int hole, Side& endSide, int& endHole) const;
	int m_evaluate(const Board& b) const;
};

#endif