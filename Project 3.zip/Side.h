#ifndef Side_H
#define Side_H

enum Side { NORTH, SOUTH }; // set north = 0
const int NSIDES = 2; // two sides
const int POT = 0; // pot as #0
inline
Side opponent(Side s)
{
	return Side(NSIDES - 1 - s); // either 0 or 1.
}
#endif