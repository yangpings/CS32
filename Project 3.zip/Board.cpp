#include "Board.h"

Board::Board(int nHoles, int nInitialBeansPerHole)
{//set initial values
	if (nHoles <= 0) nHoles = 1;
	if (nInitialBeansPerHole < 0) nInitialBeansPerHole = 0;
	m_nbeansSouthPot = m_nbeansNorthPot = 0;//no beans in the pot
	m_nholesOnASide = nHoles;//number of holes on each side
	m_nholes = m_nholesOnASide + m_nholesOnASide;//number of total holes
	m_nbeans = nInitialBeansPerHole * m_nholes;//number of total beans
	m_nbeansNorthHole = new int[nHoles];//number of total beans on north side
	m_nbeansSouthHole = new int[nHoles];//number of total beans on south side
	for (int i = 0; i < nHoles; i++) {
		m_nbeansNorthHole[i] = nInitialBeansPerHole;//#beans on north hole
		m_nbeansSouthHole[i] = nInitialBeansPerHole;//#beans on south hole
	}
}

int Board::holes() const
{
	return m_nholesOnASide;
}

int Board::beans(Side s, int hole) const
{
	if (hole == 0) {
		if (s == NORTH) return m_nbeansNorthPot;
		else return m_nbeansSouthPot;
	}
	else if (0 < hole && hole <= holes()) {
		if (s == NORTH) return m_nbeansNorthHole[hole - 1];
		else return m_nbeansSouthHole[hole - 1];
	}
	else
		return -1;
}
int Board::beansInPlay(Side s) const
{
	int nbeansInPlay = 0;
	if (s == NORTH)
	{
		for (int i = 0; i < holes(); i++)
			nbeansInPlay += m_nbeansNorthHole[i];
	}
	else if (s == SOUTH)
	{
		for (int i = 0; i < holes(); i++)
			nbeansInPlay += m_nbeansSouthHole[i];
	}
	return nbeansInPlay;//return #beans in all holes on Side s
}
int Board::totalBeans() const
{
	return m_nbeans;
}
bool Board::sow(Side s, int hole, Side& endSide, int& endHole)
{
	if (hole <= 0 || hole > holes()) return false;//invalid holes or a pot
	if (s == NORTH) {
		if (m_nbeansNorthHole[hole - 1] == 0) return false;//empty
		int beansInHole = m_nbeansNorthHole[hole - 1];
		int remainder = beansInHole;
		int count = 0;
		int dividor = holes() + holes() + 1;
		while (remainder > dividor) { 
			remainder = remainder - dividor;
			count++;
		}
		m_nbeansNorthHole[hole - 1] = 0;//take all beans from hole
		if (count > 0) {//sow count beans evenly to each hole first, then sow the remainder to individual hole
			for (int i = 0; i <= holes() - 1; i++) {
				m_nbeansNorthHole[i] += count;
				m_nbeansSouthHole[i] += count;
			}
			m_nbeansNorthPot += count;
		}
		if (remainder == 0) {//remainder=0, beans in the hole can distribute evenly to holes and the pot
			endHole = hole;
			endSide = NORTH;
			return true;
		}
		if ((hole - 1) > 0) {//sow remaining beans to north holes
			for (int i = hole - 2; i >= 0; i--) {
				m_nbeansNorthHole[i]++;
				remainder--;
				if (remainder == 0) {
					endHole = i + 1;
					endSide = NORTH;
					return true;
				}
			}
		}
		m_nbeansNorthPot++;//if there are beans left, sow to north pot
		remainder--;
		if (remainder == 0) {
			endHole = 0;
			endSide = NORTH;
			return true;
		}
		for (int i = 0; i <= holes() - 1; i++) {//if there are beans left, sow to south holes
			m_nbeansSouthHole[i]++;
			remainder--;
			if (remainder == 0) {
				endHole = i + 1;
				endSide = SOUTH;
				return true;
			}
		}
		for (int i = holes() - 1; i > hole - 2; i--) {//if there are beans left, sow to north holes, complete a cycle
			m_nbeansNorthHole[i]++;
			remainder--;
			if (remainder == 0) {
				endHole = i + 1;
				endSide = NORTH;
				return true;
			}
		}
	}
	else if (s == SOUTH) {
		if (m_nbeansSouthHole[hole - 1] == 0) return false;//empty
		int beansInHole = m_nbeansSouthHole[hole - 1];
		int remainder = beansInHole;
		int count = 0;
		int dividor = holes() + holes() + 1;
		while (remainder > dividor) {
			remainder = remainder - dividor;
			count++;
		}
		m_nbeansSouthHole[hole - 1] = 0;//take all beans from hole
		if (count > 0) {//sow count beans evenly to each hole first, then sow the remainder to individual hole
			for (int i = 0; i <= holes() - 1; i++) {
				m_nbeansNorthHole[i] += count;
				m_nbeansSouthHole[i] += count;
			}
			m_nbeansSouthPot += count;
		}
		if (remainder == 0) {//remainder=0, beans in the hole can distribute evenly to holes and the pot
			endHole = hole;
			endSide = SOUTH;
			return true;
		}

		if (hole < holes()) {//sow remaining beans to south holes
			for (int i = hole; i < holes(); i++) {
				m_nbeansSouthHole[i]++;
				remainder--;
				if (remainder == 0) {
					endHole = i + 1;
					endSide = SOUTH;
					return true;
				}
			}
		}
		m_nbeansSouthPot++;//if there are beans left, sow to south pot
		remainder--;
		if (remainder == 0) {
			endHole = 0;
			endSide = SOUTH;
			return true;
		}
		for (int i = holes() - 1; i >= 0; i--) {//if there are beans left, sow to north holes
			m_nbeansNorthHole[i]++;
			remainder--;
			if (remainder == 0) {
				endHole = i + 1;
				endSide = NORTH;
				return true;
			}
		}
		for (int i = 0; i < hole; i++) {//if there are beans left, sow to south holes, complete a cycle
			m_nbeansSouthHole[i]++;
			remainder--;
			if (remainder == 0) {
				endHole = i + 1;
				endSide = SOUTH;
				return true;
			}
		}
	}
	return true;
}
bool Board::moveToPot(Side s, int hole, Side potOwner)
{
	if (hole <= 0 || hole > holes()) return false;//invalid or pot
	if (s == NORTH) {
		if (potOwner == NORTH)
			m_nbeansNorthPot += m_nbeansNorthHole[hole - 1];
		else if (potOwner == SOUTH)
			m_nbeansSouthPot += m_nbeansNorthHole[hole - 1];
		m_nbeansNorthHole[hole - 1] = 0;
	}
	else if (s == SOUTH) {
		if (potOwner == NORTH)
			m_nbeansNorthPot += m_nbeansSouthHole[hole - 1];
		else if (potOwner == SOUTH)
			m_nbeansSouthPot += m_nbeansSouthHole[hole - 1];
		m_nbeansSouthHole[hole - 1] = 0;
	}
	return true;
}
bool Board::setBeans(Side s, int hole, int beans)
{
	if (hole < 0 || hole > holes() || beans < 0) return false;//invalid holes and negative beans
	int previous;
	if (s == NORTH) {
		if (hole == 0) {
			previous = m_nbeansNorthPot;
			m_nbeansNorthPot = beans;
		}
		else {
			previous = m_nbeansNorthHole[hole - 1];
			m_nbeansNorthHole[hole - 1] = beans;
		}
		m_nbeans += beans - previous;
		return true;
	}
	if (s == SOUTH) {
		if (hole == 0) {
			previous = m_nbeansSouthPot;
			m_nbeansSouthPot = beans;
		}
		else {
			previous = m_nbeansSouthHole[hole - 1];
			m_nbeansSouthHole[hole - 1] = beans;
		}
	    m_nbeans += beans - previous;
	    return true;
	}
	return true;
}

Board::~Board() {
	delete [] m_nbeansNorthHole;
	delete [] m_nbeansSouthHole;
}

Board::Board(const Board& other) : m_nholes(other.m_nholes), m_nholesOnASide(other.m_nholesOnASide),
m_nbeans(other.m_nbeans), m_nbeansNorthPot(other.m_nbeansNorthPot),
m_nbeansSouthPot(other.m_nbeansSouthPot)
{
	m_nbeansNorthHole = new int[m_nholesOnASide];//number of total beans on north side
	m_nbeansSouthHole = new int[m_nholesOnASide];//number of total beans on south side
	for (int i = 0; i < holes(); i++) {
		m_nbeansNorthHole[i] = other.m_nbeansNorthHole[i];//#beans on north hole
		m_nbeansSouthHole[i] = other.m_nbeansSouthHole[i];//#beans on south hole
	}
}

Board& Board::operator=(const Board& rhs) {
	if (this != &rhs)
	{
		delete[] m_nbeansNorthHole;
		delete[] m_nbeansSouthHole;

		m_nholes = rhs.m_nholes;
		m_nholesOnASide = rhs.m_nholesOnASide;
		m_nbeans = rhs.m_nbeans;
		m_nbeansSouthPot = rhs.m_nbeansSouthPot;
		m_nbeansNorthPot = rhs.m_nbeansNorthPot;

		m_nbeansNorthHole = new int[holes()];
		m_nbeansSouthHole = new int[holes()];

		for (int k = 0; k < holes(); k++) {
			m_nbeansNorthHole[k] = rhs.m_nbeansNorthHole[k];
			m_nbeansSouthHole[k] = rhs.m_nbeansSouthHole[k];
		}
	}
	return *this;
}