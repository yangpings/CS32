#ifndef Game_H
#define Game_H
#include "Board.h"
#include "Player.h"
#include "Side.h"
class Game {
public:
	Game(const Board& b, Player* south, Player* north); // constructor
	void display() const;
	void status(bool& over, bool& hasWinner, Side& winner) const; 
	bool move(Side s);
	void play();
	int beans(Side s, int hole) const;
private:
	Board m_board;
	Player* m_southPlayer;
	Player* m_northPlayer;
	Player* m_onesTurn;
	bool m_gameOver;
	bool m_hasWinner;
	Side m_winner;
	Side m_endSide;
	int m_endHole;

	//Helper Functions
	void m_mplay(Side s, int p_enter);
};
#endif