#include "Game.h"
#include <string> //added by me
using namespace std;

Game::Game(const Board& b, Player* south, Player* north) : m_board(b), m_southPlayer(south),
      m_northPlayer(north), m_onesTurn(m_southPlayer), m_gameOver(false), m_hasWinner(false), m_winner(SOUTH)
{
}
void Game::display() const
{
    cout << "    " << m_northPlayer->name() << endl;//North player name
    cout << " ";
    for (int i = 1; i <= m_board.holes(); i++) {//North Player's Holes
        cout << "   " << beans(NORTH, i);
    }
    cout << endl;

    cout << " " << beans(NORTH, 0);//North Player's Pot
    for (int i = 1; i <= m_board.holes(); i++) {
        cout << "    ";
    }
    cout << " " << beans(SOUTH, 0) << endl;//South Player's Pot
    cout << " ";
    for (int i = 1; i <= m_board.holes(); i++){//South Player's Holes
        cout << "   " << beans(SOUTH, i);
    }
    cout << endl;
    cout << "    ";
    cout << m_southPlayer->name() << endl; //South player name
}

void Game::status(bool& over, bool& hasWinner, Side& winner) const
{
    if (m_board.beansInPlay(NORTH) > 0 && m_board.beansInPlay(SOUTH) > 0) {//game not over
        over = false;
    }
    else {//game over
        over = true;
        if (beans(NORTH, 0) > beans(SOUTH, 0))//North Player wins
        {
            hasWinner = true;
            winner = NORTH;
        }
        else if (beans(SOUTH, 0) > beans(NORTH, 0))//South Player wins
        {
            hasWinner = true;
            winner = SOUTH;
        }
        else
            hasWinner = false;//tie
    }
}

bool Game::move(Side s)
{
    status(m_gameOver, m_hasWinner, m_winner);
    if (m_gameOver == true)//game over, sweep
    {
        if (m_board.beansInPlay(NORTH) == 0 && m_board.beansInPlay(SOUTH) > 0)
        {
            for (int i = 1; i <= m_board.holes(); i++)
                m_board.moveToPot(SOUTH, i, SOUTH);
            cout << "Sweep the remaining beans into " << m_southPlayer->name() << "'s pot." << endl;
        }
        else if (m_board.beansInPlay(NORTH) > 0 && m_board.beansInPlay(SOUTH) == 0)
        {
            for (int i = 1; i <= m_board.holes(); i++)
                m_board.moveToPot(NORTH, i, NORTH);
            cout << "Sweep the remaining beans into " << m_northPlayer->name() << "'s pot." << endl;
        }
        status(m_gameOver, m_hasWinner, m_winner);//update status
        return false;
    }

    if (s == NORTH)
        m_onesTurn = m_northPlayer;
    else if(s== SOUTH)
        m_onesTurn = m_southPlayer;

    int chooseHole = m_onesTurn->chooseMove(m_board, s);
    if (chooseHole == -1) return false;

    cout << m_onesTurn->name() << ((s==NORTH)?" (N)" : " (S)") << " choose hole " << chooseHole << endl;
    cout << "        ||" << endl << "        \\/" << endl;
    if (m_board.sow(s, chooseHole, m_endSide, m_endHole) == true) {
        if ((s == m_endSide) && (m_board.beans(m_endSide, m_endHole) == 1) && 
            (m_board.beans(opponent(m_endSide), m_endHole) > 0)) {
            m_board.moveToPot(m_endSide, m_endHole, m_endSide);
            m_board.moveToPot(opponent(m_endSide), m_endHole, m_endSide);
        }
        display();
        if (m_board.beansInPlay(NORTH) == 0 && m_board.beansInPlay(SOUTH) > 0)
        {
            for (int i = 1; i <= m_board.holes(); i++)
                m_board.moveToPot(SOUTH, i, SOUTH);
            cout << "One side zero beans, ";
            cout << "sweep the remaining beans into " << m_southPlayer->name() << "'s pot." << endl;
        }
        else if (m_board.beansInPlay(NORTH) > 0 && m_board.beansInPlay(SOUTH) == 0)
        {
            for (int i = 1; i <= m_board.holes(); i++)
                m_board.moveToPot(NORTH, i, NORTH);
            cout << "One side zero beans, ";
            cout << "sweep the remaining beans into " << m_northPlayer->name() << "'s pot." << endl;
        }

        while (m_endHole == 0) {
            chooseHole = m_onesTurn->chooseMove(m_board, s);
            if (chooseHole == -1) return false;

            cout << m_onesTurn->name() << ((s == NORTH) ? " (N)" : " (S)") << " choose hole " << chooseHole << endl;
            cout << "        ||" << endl << "        \\/" << endl;
            m_board.sow(s, chooseHole, m_endSide, m_endHole);
            //capture
            if ((s == m_endSide) && (m_board.beans(m_endSide, m_endHole) == 1) &&
                (m_board.beans(opponent(m_endSide), m_endHole) > 0)) {
                m_board.moveToPot(m_endSide, m_endHole, m_endSide);
                m_board.moveToPot(opponent(m_endSide), m_endHole, m_endSide);
            }     

            display();
            if (m_board.beansInPlay(NORTH) == 0 && m_board.beansInPlay(SOUTH) > 0)
            {
                for (int i = 1; i <= m_board.holes(); i++)
                    m_board.moveToPot(SOUTH, i, SOUTH);
                cout << "One side zero beans, ";
                cout << "sweep the remaining beans into " << m_southPlayer->name() << "'s pot." << endl;
            }
            else if (m_board.beansInPlay(NORTH) > 0 && m_board.beansInPlay(SOUTH) == 0)
            {
                for (int i = 1; i <= m_board.holes(); i++)
                    m_board.moveToPot(NORTH, i, NORTH);
                cout << "One side zero beans, ";
                cout << "sweep the remaining beans into " << m_northPlayer->name() << "'s pot." << endl;
            }
        }
    }
    status(m_gameOver, m_hasWinner, m_winner);
    return true;
}

void Game::play()
{
    display();
    m_mplay(SOUTH, 0);
}

int Game::beans(Side s, int hole) const
{
    return m_board.beans(s, hole);
}

//Helper Functions
void Game::m_mplay(Side s, int p_enter) {
    move(s);
    if (m_gameOver) {
        if(m_winner == NORTH)
            cout << "The winner is: " << m_northPlayer->name() << " (N)" << endl;
        else
            cout << "The winner is: " << m_southPlayer->name() << " (S)" << endl;
        display();
        cout << "Press ENTER to continue: ";
        cin.clear();//prevent input error of other symbols
        cin.ignore(10000, '\n');//prevent input error of other symbols
        return;
    }
    if (!m_northPlayer->isInteractive() && !m_southPlayer->isInteractive()) {
        cout << "Press ENTER to continue: ";
        if (p_enter == 0) cin.get();
        cin.clear(); //prevent input error of other symbols
        cin.ignore(10000, '\n'); //prevent input error of other symbols
    }
    m_mplay(opponent(s), p_enter + 1);
}
