#include "Player.h"

Player::Player(std::string name) : m_name(name)
{
}

std::string Player::name() const
{
	return m_name;
}

bool Player::isInteractive() const
{
	return false;
}

int Player::chooseMove(const Board& b, Side s) const
{
	return -1;
}

Player::~Player()
{
}

HumanPlayer::HumanPlayer(std::string name) : Player(name)
{
}

bool HumanPlayer::isInteractive() const
{
	return true;
}

int HumanPlayer::chooseMove(const Board& b, Side s) const
{
    if (b.beansInPlay(s) == 0) return -1;//stop criteria
    std::cout << "Select a hole to move, " << name() << ": ";
    int holeToMove;
    std::cin >> holeToMove;

    while (holeToMove <= 0 || holeToMove > b.holes() || b.beans(s, holeToMove) == 0)
    {
        if (b.beans(s, holeToMove) == 0) {
            std::cout << "There are no beans in the hole." << std::endl;
            std::cout << "Select a hole to move, " << name() << ": ";
        }
        else if (holeToMove <= 0 || holeToMove > b.holes()) {
            std::cout << "The hole number must between 1 and " << b.holes() << "." << std::endl;
        }
     std::cin.clear();//prevent input error of other symbols
     std::cin.ignore(10000, '\n');//prevent input error of other symbols
     std::cin >> holeToMove;
    }
    return holeToMove;
}

HumanPlayer::~HumanPlayer()
{
}

BadPlayer::BadPlayer(std::string name) : Player(name)
{
}

bool BadPlayer::isInteractive() const
{
	return false;
}

int BadPlayer::chooseMove(const Board& b, Side s) const
{
    if (b.beansInPlay(s) == 0) return -1;//stop criteria
    for (int holeToMove = 1; holeToMove <= b.holes(); holeToMove++) {
        if (b.beans(s, holeToMove) > 0) return holeToMove;
    }
    return -1;
}

BadPlayer::~BadPlayer()
{
}

SmartPlayer::SmartPlayer(std::string name) : Player(name)
{
}

bool SmartPlayer::isInteractive() const
{
	return false;
}

int SmartPlayer::chooseMove(const Board& b, Side s) const
{
    clock_t t = clock();
    int bestHole, value, depth = 0;
    m_chooseMove(s, b, bestHole, value, depth, t);
    return bestHole;
}

SmartPlayer::~SmartPlayer()
{
}

void SmartPlayer::m_chooseMove(Side s, const Board& b, int & bestHole, int & value, int depth, clock_t t) const {
    //no move for player
    if (b.beansInPlay(s) == 0) {
        bestHole = -1;
        value = m_evaluate(b);
        return;
    }
    //depth criterion
    if (depth > 5) {
        bestHole = -1;
        value = m_evaluate(b);
        return;
    }
    //time elapsed limited to no more than 5 secs.
    if ((float)(clock() - t) / CLOCKS_PER_SEC > 4.5) { 
        bestHole = -1;
        value = m_evaluate(b);
        return;
    }

    int h_left = 1;
    for (int h = 1; h <= b.holes(); h++) {
        if (b.beans(s, h) == 0) {
            h_left++;
            continue;
        }
        if (b.beans(s, h) > 0) {
            Board b_copy = b;
            Side endSide;
            int endHole, h2, v2;            
            if (m_move(s, b_copy, h, endSide, endHole) == true) {
                m_chooseMove(opponent(s), b_copy, h2, v2, depth + 1, t);
            }
            else {
                m_chooseMove(s, b_copy, h2, v2, depth, t);
            }
            b_copy = b;
            if (h == h_left) { //set h to the first nonzero hole to prevent error
                bestHole = h;
                value = v2;
            }
            if (s == SOUTH) {
                if (v2 > value) {
                    bestHole = h;
                    value = v2;
                }
            }
            else {
                if (v2 < value) {
                    bestHole = h;
                    value = v2;
                }
            }
            if ((float)(clock() - t) / CLOCKS_PER_SEC > 4.5) break;
        }
    }
    return;
}

bool SmartPlayer::m_move(Side s, Board& b, int hole, Side& endSide, int& endHole) const {
    if (b.sow(s, hole, endSide, endHole) == true) {
        // can do another move
        if (endHole == 0) {        
            //sweep
            if (b.beansInPlay(NORTH) == 0 && b.beansInPlay(SOUTH) > 0)
            {
                for (int i = 1; i <= b.holes(); i++)
                    b.moveToPot(SOUTH, i, SOUTH);
            }
            else if (b.beansInPlay(NORTH) > 0 && b.beansInPlay(SOUTH) == 0)
            {
                for (int i = 1; i <= b.holes(); i++)
                    b.moveToPot(NORTH, i, NORTH);
            }
            return false;
        }
        //capture
        else if ((s == endSide) && (b.beans(endSide, endHole) == 1) &&
            (b.beans(opponent(endSide), endHole) > 0)) {
            b.moveToPot(endSide, endHole, endSide);
            b.moveToPot(opponent(endSide), endHole, endSide);
            //sweep
            if (b.beansInPlay(NORTH) == 0 && b.beansInPlay(SOUTH) > 0) {
                for (int i = 1; i <= b.holes(); i++)
                    b.moveToPot(SOUTH, i, SOUTH);
            }
            else if (b.beansInPlay(NORTH) > 0 && b.beansInPlay(SOUTH) == 0)
            {
                for (int i = 1; i <= b.holes(); i++)
                    b.moveToPot(NORTH, i, NORTH);
            }
        }
        return true;
    }
    return false;
}

int SmartPlayer::m_evaluate(const Board& b) const {//value of SOUTH
    int nBeans = b.beansInPlay(NORTH);
    int sBeans = b.beansInPlay(SOUTH);
    int nPot = b.beans(NORTH, 0);
    int sPot = b.beans(SOUTH, 0);

    if ((sPot - nPot) > (sBeans + nBeans)) {
        return 10000;
    }
    else if ((nPot - sPot) > (sBeans + nBeans)) {
        return -10000;
    }
    else
        return sPot - nPot;
}