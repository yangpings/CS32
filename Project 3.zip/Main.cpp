﻿#include "Game.h"
#include "Player.h"
#include "Board.h"
#include "Side.h"
#include <iostream>
#include <cassert>
using namespace std;

void doBoardTests()
{
	Board b(3, 2);
	assert(b.holes() == 3 && b.totalBeans() == 12 &&
		b.beans(SOUTH, POT) == 0 && b.beansInPlay(SOUTH) == 6);
	b.setBeans(SOUTH, 1, 1);
	b.moveToPot(SOUTH, 2, SOUTH);
	assert(b.totalBeans() == 11 && b.beans(SOUTH, 1) == 1 &&
		b.beans(SOUTH, 2) == 0 && b.beans(SOUTH, POT) == 2 &&
		b.beansInPlay(SOUTH) == 3);
	Side es;
	int eh;
	b.sow(SOUTH, 3, es, eh);
	assert(es == NORTH && eh == 3 && b.beans(SOUTH, 3) == 0 &&
		b.beans(NORTH, 3) == 3 && b.beans(SOUTH, POT) == 3 &&
		b.beansInPlay(SOUTH) == 1 && b.beansInPlay(NORTH) == 7);
}

void doPlayerTests()
{
	HumanPlayer hp("Marge");
	assert(hp.name() == "Marge" && hp.isInteractive());
	BadPlayer bp("Homer");
	assert(bp.name() == "Homer" && !bp.isInteractive());
	SmartPlayer sp("Lisa");
	assert(sp.name() == "Lisa" && !sp.isInteractive());
	Board b(3, 2);
	b.setBeans(SOUTH, 2, 0);
	cout << "=========" << endl;
	int n = hp.chooseMove(b, SOUTH);
	cout << "=========" << endl;
	assert(n == 1 || n == 3);
	n = bp.chooseMove(b, SOUTH);
	assert(n == 1 || n == 3);
	n = sp.chooseMove(b, SOUTH);
	assert(n == 1 || n == 3);
}

void doGameTests()
{
	BadPlayer bp1("Bart");
	BadPlayer bp2("Homer");
	Board b(3, 0);
	b.setBeans(SOUTH, 1, 2);
	b.setBeans(NORTH, 2, 1);
	b.setBeans(NORTH, 3, 2);
	Game g(b, &bp1, &bp2);
	bool over;
	bool hasWinner;
	Side winner;
	//    Homer
	//   0  1  2
	// 0         0
	//   2  0  0
	//    Bart
	g.status(over, hasWinner, winner);
	assert(!over && g.beans(NORTH, POT) == 0 && g.beans(SOUTH, POT) == 0 &&
		g.beans(NORTH, 1) == 0 && g.beans(NORTH, 2) == 1 && g.beans(NORTH, 3) == 2 &&
		g.beans(SOUTH, 1) == 2 && g.beans(SOUTH, 2) == 0 && g.beans(SOUTH, 3) == 0);

	g.move(SOUTH);
	//   0  1  0
	// 0         3
	//   0  1  0
	g.status(over, hasWinner, winner);
	assert(!over && g.beans(NORTH, POT) == 0 && g.beans(SOUTH, POT) == 3 &&
		g.beans(NORTH, 1) == 0 && g.beans(NORTH, 2) == 1 && g.beans(NORTH, 3) == 0 &&
		g.beans(SOUTH, 1) == 0 && g.beans(SOUTH, 2) == 1 && g.beans(SOUTH, 3) == 0);

	g.move(NORTH);
	//   1  0  0
	// 0         3
	//   0  1  0
	g.status(over, hasWinner, winner);
	assert(!over && g.beans(NORTH, POT) == 0 && g.beans(SOUTH, POT) == 3 &&
		g.beans(NORTH, 1) == 1 && g.beans(NORTH, 2) == 0 && g.beans(NORTH, 3) == 0 &&
		g.beans(SOUTH, 1) == 0 && g.beans(SOUTH, 2) == 1 && g.beans(SOUTH, 3) == 0);

	g.move(SOUTH);
	//   1  0  0
	// 0         3
	//   0  0  1
	g.status(over, hasWinner, winner);
	assert(!over && g.beans(NORTH, POT) == 0 && g.beans(SOUTH, POT) == 3 &&
		g.beans(NORTH, 1) == 1 && g.beans(NORTH, 2) == 0 && g.beans(NORTH, 3) == 0 &&
		g.beans(SOUTH, 1) == 0 && g.beans(SOUTH, 2) == 0 && g.beans(SOUTH, 3) == 1);

	g.move(NORTH);
	//   0  0  0
	// 1         4
	//   0  0  0
	g.status(over, hasWinner, winner);
	assert(over && g.beans(NORTH, POT) == 1 && g.beans(SOUTH, POT) == 4 &&
		g.beans(NORTH, 1) == 0 && g.beans(NORTH, 2) == 0 && g.beans(NORTH, 3) == 0 &&
		g.beans(SOUTH, 1) == 0 && g.beans(SOUTH, 2) == 0 && g.beans(SOUTH, 3) == 0);
	assert(hasWinner && winner == SOUTH);
}

int main()
{
	doBoardTests();
	cout << "Passed all doBoardrTests();" << endl;
	doPlayerTests();
	cout << "Passed all doPlayerTests();" << endl;
	doGameTests();
	cout << "Passed all doGameTests()" << endl;
	SmartPlayer hp("Marge");
	BadPlayer bp("Homer");
	Board b(3, 2);
	Game g(b, &hp, &bp);
	g.play();

    // The above are teacher's test cases.
    // My tests begins below:
    // Test Board class
    // Test Board(int nHoles, int nInitialBeansPerHole);
    //   4  4  4
    // 0         0
    //   4  4  4
    Board b34(3, 4);
    //   0
    // 0   0
    //   0
    Board b00(-1, -1);
    // Test holes to check the return value
    assert(b34.holes() == 3);
    assert(b00.holes() == 1);
    // Test beans to check the number of beans in each hole
    assert(b34.beans(NORTH, 0) == 0);
    assert(b34.beans(NORTH, 1) == 4);
    assert(b34.beans(NORTH, 2) == 4);
    assert(b34.beans(NORTH, 3) == 4);
    assert(b34.beans(SOUTH, 0) == 0);
    assert(b34.beans(SOUTH, 1) == 4);
    assert(b34.beans(SOUTH, 2) == 4);
    assert(b34.beans(SOUTH, 3) == 4);
    assert(b00.beans(NORTH, 0) == 0);
    assert(b00.beans(NORTH, 1) == 0);
    assert(b00.beans(NORTH, 2) == -1);
    assert(b00.beans(SOUTH, 0) == 0);
    assert(b00.beans(SOUTH, 1) == 0);
    assert(b00.beans(SOUTH, 2) == -1); 
    //Test beansInPlay to check the beans in play in each side
    assert(b34.beansInPlay(NORTH) == 12);
    assert(b34.beansInPlay(SOUTH) == 12);
    assert(b00.beansInPlay(NORTH) == 0);
    assert(b00.beansInPlay(NORTH) == 0);
    //Test totalBeans to check the return value
    assert(b34.totalBeans() == 24);
    assert(b00.totalBeans() == 0);
    //Test sow to check the process during the sow
    Side endS;
    int endH;
    assert(b34.sow(NORTH, 1, endS, endH) == true);
    //   4  4  4
    // 0         0
    //   4  4  4
    //      |
    //      V
    //   0  4  4
    // 1         0
    //   5  5  5*
    assert(endS == SOUTH);
    assert(endH == 3);
    assert(b34.sow(NORTH, 1, endS, endH) == false);
    assert(b34.sow(NORTH, 2, endS, endH) == true);
    //   0  4  4
    // 1         0
    //   5  5  5
    //      |
    //      V
    //   1  0  4
    // 2         0
    //   6  6* 5
    assert(endS == SOUTH);
    assert(endH == 2);
    assert(b34.sow(NORTH, 1, endS, endH) == true);
    //   1  0  4
    // 2         0
    //   6  6  5
    //      |
    //      V
    //   0  0  4
    // 3*        0
    //   6  6  5
    assert(endS == NORTH);
    assert(endH == 0);
    assert(b34.sow(SOUTH, 2, endS, endH) == true);
    //   0  0  4
    // 3         0
    //   6  6  5
    //      |
    //      V
    //   1  1  5
    // 3         1
    //   7* 0  6
    assert(endS == SOUTH);
    assert(endH == 1);
    assert(b34.sow(SOUTH, 1, endS, endH) == true);
    //   1  1  5
    // 3         1
    //   7  0  6
    //      |
    //      V
    //   2  2  6
    // 3         2
    //   1* 1  7
    assert(endS == SOUTH);
    assert(endH == 1);
    assert(b34.beans(NORTH, 0) == 3);
    assert(b34.beans(NORTH, 1) == 2);
    assert(b34.beans(NORTH, 2) == 2);
    assert(b34.beans(NORTH, 3) == 6);
    assert(b34.beans(SOUTH, 0) == 2);
    assert(b34.beans(SOUTH, 1) == 1);
    assert(b34.beans(SOUTH, 2) == 1);
    assert(b34.beans(SOUTH, 3) == 7);
    //now, test beansInPlay
    assert(b34.beansInPlay(NORTH) == 10);
    assert(b34.beansInPlay(SOUTH) == 9);
    //now, test totalBeans
    assert(b34.totalBeans() == 24);
    //Test moveToPot to check if it can move the beans of the hole on one side to the owner's pot
    assert(b34.moveToPot(SOUTH, 4, SOUTH) == false);
    assert(b34.moveToPot(SOUTH, 0, SOUTH) == false);
    assert(b34.moveToPot(SOUTH, 1, SOUTH) == true);
    //   2  2  6
    // 3         2
    //   1  1  7
    //      |
    //      V
    //   2  2  6
    // 3         3
    //   0  1  7
    assert(b34.beans(SOUTH, 0) == 3);
    assert(b34.moveToPot(NORTH, 2, NORTH) == true);
    //   2  2  6
    // 3         3
    //   0  1  7
    //      |
    //      V
    //   2  0  6
    // 5         3
    //   0  1  7
    assert(b34.beans(NORTH, 0) == 5);
    assert(b34.moveToPot(SOUTH, 2, NORTH) == true);
    //   2  0  6
    // 5         3
    //   0  1  7
    //      |
    //      V
    //   2  0  6
    // 6         3
    //   0  0  7
    assert(b34.beans(NORTH, 0) == 6);
    assert(b34.moveToPot(NORTH, 3, SOUTH) == true);
    //   2  0  6
    // 6         3
    //   0  0  7
    //      |
    //      V
    //   2  0  0
    // 6         9
    //   0  0  7
    assert(b34.beans(SOUTH, 0) == 9);
    //Test setBeans
    //   2  0  0
    // 6         9
    //   0  0  7
    assert(b34.beansInPlay(NORTH) == 2);
    assert(b34.beansInPlay(SOUTH) == 7);
    assert(b34.totalBeans() == 24);
    assert(b34.beans(SOUTH, 1) == 0);
    assert(b34.setBeans(SOUTH, 1, 5) == true);
    //   2  0  0
    // 6         9
    //   5  0  7
    assert(b34.beans(SOUTH, 1) == 5);
    assert(b34.totalBeans() == 29);
    assert(b34.beansInPlay(SOUTH) == 12);
    assert(b34.beans(SOUTH, 3) == 7);
    assert(b34.setBeans(SOUTH, 3, 1) == true);
    //   2  0  0
    // 6         9
    //   5  0  1
    assert(b34.beans(SOUTH, 3) == 1);
    assert(b34.totalBeans() == 23);
    assert(b34.beansInPlay(SOUTH) == 6);
    assert(b34.beans(NORTH, 1) == 2);
    assert(b34.setBeans(NORTH, 1, 0) == true);
    //   0  0  0
    // 6         9
    //   5  0  1
    assert(b34.beans(NORTH, 1) == 0);
    assert(b34.totalBeans() == 21);
    assert(b34.beansInPlay(NORTH) == 0);
    cerr << "Passed my Board Tests" << endl;

    // Test Player class
    // Test name, isInteractive methods
    HumanPlayer hplayer("human");
    assert(hplayer.name() == "human");
    assert(hplayer.isInteractive());
    BadPlayer bplayer("bad");
    assert(bplayer.name() == "bad");
    assert(!bplayer.isInteractive());
    SmartPlayer splayer("smart");
    assert(splayer.name() == "smart");
    assert(!splayer.isInteractive());
    // Test chooseMove, the bad player always move the first nonempty holes from the smallest number
    //   0  0  0
    // 6         9
    //   5  0  1
    assert(bplayer.chooseMove(b34, NORTH) == -1 && bplayer.chooseMove(b34, SOUTH) == 1);
    cout << "   bad" << endl;
    cout << "   0  0  0" << endl;
    cout << " 6         9" << endl;
    cout << "   5  0  1" << endl;
    cout << "   human" << endl;

    int n = hplayer.chooseMove(b34, SOUTH);
    assert(n == 1 || n == 3);
    cerr << "Passed my Player Tests" << endl;
   
    // Test Game class
// The Player class is used to keep the name and choose which hole to move, in bad or smart manner,
// interactively or not interactively. 
// When the players are playing the game, they decide who is SOUTH and who is NORTH. Then SOUTH and NORTH
// data are created and stored as Board class. Game class implements the rules and chooses the style to 
// display and designs how to play the game. It also checks when the game is over and who is the winner.

    Board b32(3, 2);
    Game g1(b32, &bplayer, &bplayer);
    Board b64(6, 4);
    Game g2(b64, &splayer, &bplayer);
    Board b41(4, 1);
    Game g3(b41, &hplayer, &bplayer);
    Board b42(4, 2);
    Game g4(b42, &splayer, &hplayer);
    // Test display
    g1.display();
    g2.display();
    g3.display();
    g4.display();
    // Test status(bool& over, bool& hasWinner, Side& winner)
    bool over1;
    bool hasWinner1 = false;
    Side winner1 = SOUTH;
    g1.status(over1, hasWinner1, winner1);
    assert(over1 == false && hasWinner1 == false && winner1 == SOUTH);
    // Test bad v.s. bad
   g1.play();//
    // Test smart v.s. bad
    g2.play();//
// When we test games of two non-interactive players twice,
// a one time, unexpected double-click enter required for the second "press enter to continue"
// in the second game.  If the test asked me to click numbers between the two 
// consecutive games, unanted, double-click enter behavior does not happen.
    // Test human(interactive) v.s. smart
    g3.play();
    // Test smart v.s. human(interactive)
    g4.play();

//  When the number of holes is large, ex. 30, smart player on south side acts as the dummy, bad player,
//  since the bad player always choose the smallest non empty hole to move, which is near his/her pot when
//  he/she is on north side. Although smart player's choosemove search from the smallest number to the large
//  number and penetrated to the depth we recommend, if there is no time limit to the game tree, he is smart.
//  But if time is limited to 5 seconds and the number of holes is large, it acts as a bad player when he/she
//  is on the south side because the smart player will suggest a small hole to move, which makes a longer
//  diatance for the beans to move to his/her pot.
// 
//  We have check the cases when depth is selected from small to large:
//  Without time limit, if the depth is large, the smart player can do well.
//  Since time limit is 5 secs, when the depth is large, the smart player can not check thoroughly, and tends to 
//  the bad behavior on critical conditions(on South side, and large hole number)


//  With a time limit, for a large hole number, smart player on NORTH side take advantages over bad play 
    Board b2002(200, 2);
    Game g5(b2002, &bplayer, &splayer);
    // Test bad v.s. smart
    g5.play();
//  With a time limit, for a large hole number, smart player on SOUTH side does not check thoroughly, and 
//  does not efficiently take advantage over bad player  
    Board b3002(300, 2);
    Game g6(b3002, &splayer, &bplayer);
    // Test smart v.s. bad
    g6.play();


    cout << "Passed my Game tests" << endl;
 }