// Dictionary.cpp

// the letters of the words "eat", "eta", "ate", "tea" can be decomposed and sorted as aet
// so when we search the word "tea", these words are printed.
// If we use different prime numbers for a-z letters in thePrime function, then the function
// wordtonum multiplies them to get a number, the number is a unique key for these words,
// just like prime factorization of the whole number.
// The word we search gives us the prime factorization of the whole number, so we calculate the product to 
// obtain the whole number
// if a=2, e=3, t=5, then 2x3x5=30 represent the unique key of aet
// So any word that can be factorized to the same number has the same key.
// Separate chaining is adopted in the code, so the words that have the same prime product are stored in
// the same m_table[i]. Since different prime products % 49999 may have the same i, we store the prime
// product to thekey[i]. We can compare thekey[i] with the prime product to check the words to print.

#include "Dictionary.h"
#include <string>
#include <list>
#include <cctype>
using namespace std;

void removeNonLetters(string& s);
static const int maxCapacity = 49999;//largest prime number less than 50000 
unsigned long thekey[maxCapacity];
int thePrime(char ch);
int wordtonum(const string& theword);
int hashFunction(unsigned long);

  // This class does the real work of the implementation.

class DictionaryImpl
{
  public:
    DictionaryImpl(int /* maxBuckets */) {
        for (int i = 0; i < maxCapacity; i++) {
            m_table[i] = nullptr;
        }
    }
    ~DictionaryImpl() {
        for (int i = 0; i < maxCapacity; i++) {//delete link listed pointer to prevent memory leaks
            Node* nodep = m_table[i];
            while (nodep != nullptr)
            {
                Node* nextnodep = nodep->next;
                delete nodep;
                nodep = nextnodep;
            }
        }
    }
    void insert(string word);
    void lookup(string letters, void callback(string)) const;
  private:
    class Node
    {
    public:
        Node(string theword, Node* nextptr = nullptr);
        string word;
        Node* next;
    };
    Node* m_table[maxCapacity];
};

DictionaryImpl::Node::Node(string theword, Node* nextptr) {
    this->word = theword;
    this->next = nextptr;
}

void DictionaryImpl::insert(string word)
{
    removeNonLetters(word);
    Node* newNodeptr = new Node(word);
    int key = wordtonum(word);//transform word to key
    int pos = hashFunction(key);//find the pos of the key
    thekey[pos] = key;
    if (m_table[pos] == nullptr) {
        m_table[pos] = newNodeptr;//if empty, m_table[pos] points to the first node
    }
    else {
        Node* nodeptr = m_table[pos];
        while (nodeptr->next != nullptr) {//find last node
            nodeptr = nodeptr->next;
        }
        nodeptr->next = newNodeptr;//inset after the last node
    }
}

void DictionaryImpl::lookup(string letters, void callback(string)) const
{
    if (callback == nullptr)
        return;

    removeNonLetters(letters);
    if (letters.empty())
        return;

    int key = wordtonum(letters);//transform letters to key
    int pos = hashFunction(key);//find the pos of the key
    Node* theptr = m_table[pos];//point to the first node
    while (theptr != nullptr) {//if not point to nullptr
        callback(theptr->word);//print the word on the node
        theptr = theptr->next;// next node
    }
}

//most frequently used letters are asigned to smaller values to avoid large products
// e, t, a, o, i, n, s, r, h, l, d, c, u, m, f, p, g, w, y, b, v, k, x, j, q, z

int thePrime(char ch)
{
    switch (ch)
    {
    case 'a':  return 5;    break;       case 'b':  return 71;   break;
    case 'c':  return 37;   break;       case 'd':  return 31;   break;
    case 'e':  return 2;    break;       case 'f':  return 47;   break;
    case 'g':  return 59;   break;       case 'h':  return 23;   break;
    case 'i':  return 11;   break;       case 'j':  return 89;   break;
    case 'k':  return 79;   break;       case 'l':  return 29;   break;
    case 'm':  return 43;   break;       case 'n':  return 13;   break;
    case 'o':  return 7;    break;       case 'p':  return 53;   break;
    case 'q':  return 97;   break;       case 'r':  return 19;   break;
    case 's':  return 17;   break;       case 't':  return 3;    break;
    case 'u':  return 41;   break;       case 'v':  return 73;   break;
    case 'w':  return 61;   break;       case 'x':  return 83;   break;
    case 'y':  return 67;   break;       case 'z':  return 101;  break;
    default:   return 0;
    }
    return 0;
}

int wordtonum(const string& theword) {
    unsigned long thenum = 1;
    for (unsigned int k = 0; k < theword.size(); k++)
    {
        thenum *= thePrime(theword[k]);//product of the prime factorization
    }
    return thenum;
}

int hashFunction(unsigned long newkey) {//find pos of the word (thiskey)
    int thiskey = newkey % maxCapacity;//make bounds
    while (thekey[thiskey] != 0 && thekey[thiskey] != newkey) {//pos not empty, and the key is different
        thiskey = (thiskey + 1009) % maxCapacity;//pos increased by 1009, a prime number
    }        
    return thiskey;
}

void removeNonLetters(string& s)
{
    string::iterator to = s.begin();
    for (string::const_iterator from = s.begin(); from != s.end(); from++)
    {
        if (isalpha(*from))
        {
            *to = tolower(*from);
            to++;
        }
    }
    s.erase(to, s.end());  // chop everything off from "to" to end.
} 

//******************** Dictionary functions ******************************

// These functions simply delegate to DictionaryImpl's functions
// You probably don't want to change any of this code

Dictionary::Dictionary(int maxBuckets)
{
    m_impl = new DictionaryImpl(maxBuckets);
}

Dictionary::~Dictionary()
{
    delete m_impl;
}

void Dictionary::insert(string word)
{
    m_impl->insert(word);
}

void Dictionary::lookup(string letters, void callback(string)) const
{
    m_impl->lookup(letters,callback);
}
