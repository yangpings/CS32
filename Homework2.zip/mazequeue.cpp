#include <iostream>
#include <queue>
using namespace std;

class Coord
{
public:
    Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
    int r() const { return m_r; }
    int c() const { return m_c; }
private:
    int m_r;
    int m_c;
};

bool pathExists(char maze[10][10], int sr, int sc, int er, int ec) 
{
    queue<Coord> coordQueue;
    Coord start(sr, sc);
    coordQueue.push(start);
    char cvalue = 'o';
    maze[sr][sc] = cvalue;
    int posr, posc;
    while (!coordQueue.empty())
    {
        Coord frontitem = coordQueue.front();
        posr = frontitem.r();
        posc = frontitem.c();

        coordQueue.pop();
        if (posr == er && posc == ec) return true;

        if (maze[posr + 1][posc] == '.')
        {
            Coord canmovesouth(posr + 1, posc);
            coordQueue.push(canmovesouth);
            maze[posr + 1][posc] = cvalue;
        }

        if (maze[posr][posc + 1] == '.')
        {
            Coord canmoveeast(posr, posc + 1);
            coordQueue.push(canmoveeast);
            maze[posr][posc + 1] = cvalue;
        }

        if (maze[posr - 1][posc] == '.')
        {
            Coord canmovenorth(posr - 1, posc);
            coordQueue.push(canmovenorth);
            maze[posr - 1][posc] = cvalue;
        }

        if (maze[posr][posc - 1] == '.')
        {
            Coord canmovewest(posr, posc - 1);
            coordQueue.push(canmovewest);
            maze[posr][posc - 1] = cvalue;
        }

    }
    return false;
}



int main()
{
    char maze[10][10] = {
            { 'X','X','X','X','X','X','X','X','X','X' },
            { 'X','.','.','.','X','.','.','.','.','X' },
            { 'X','.','.','X','X','.','X','X','.','X' },
            { 'X','.','X','.','.','.','.','X','X','X' },
            { 'X','X','X','X','.','X','X','X','.','X' },
            { 'X','.','.','X','.','.','.','X','.','X' },
            { 'X','.','.','X','.','X','.','.','.','X' },
            { 'X','X','.','X','.','X','X','X','X','X' },
            { 'X','.','.','.','.','.','.','.','.','X' },
            { 'X','X','X','X','X','X','X','X','X','X' }
     };

     if (pathExists(maze, 3, 4, 8, 1))
         cout << "Solvable!" << endl;
     else
         cout << "Out of luck!" << endl;
}