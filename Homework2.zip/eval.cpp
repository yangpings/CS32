#include <iostream>
#include <string>
#include <stack>
#include <cassert>
using namespace std;

int evaluate(string infix, string& postfix, bool& result)
{
	postfix = "";//Initialize postfix to empty
	if (infix.size() > 0)//infix shouldn't be empty
	{
		while (infix.find(' ') != -1)//remove all blanks if exist
			infix.erase(infix.find(' '), 1);
		int j = 0;
		for (unsigned int i = 0; i < infix.size(); i++)//check parentheses (pairs)
		{
			if (infix[i] == '(') j++;
			if (infix[i] == ')') j--;
			if (j < 0) return 1;
		}
		if (j != 0) return 1;

		switch (infix[infix.size() - 1])//last ch could only be T,F,)
		{
		case 'F': case 'T': case ')':
			break;
		default:
			return 1;
		}
	}
	else 
		return 1;

	stack<char> operatorstack;//Initialize the operator stack to empty
	for (unsigned int i = 0; i < infix.size(); i++)
	{
		switch (infix[i]) {
			case('T'): case('F'):
				if (i > 0 && (infix[i - 1] == 'T' || infix[i - 1] == 'F'))//no TF,FT,FF,TT allowed
					return 1;
				postfix += infix[i];
				break;

			case('('):
				if (i > 0 && (infix[i - 1] == 'T' || infix[i - 1] == 'F'))// no T,F before (
					return 1;
				operatorstack.push(infix[i]);
				break;

			case(')'):
				if (infix[i - 1] == '(')//no () allowed
					return 1;
				while (operatorstack.top() != '(')
				{
					postfix += operatorstack.top();
					operatorstack.pop();
				}
				operatorstack.pop();
				break;
			case('!'): case('&'): case('^'):
				if (infix[i] == '!')
				{
					if (infix[i-1] == 'T' || infix[i - 1] == 'F')//no T,F allowed before !
						return 1;
				}
				else if (infix[i - 1] == '(' || infix[i - 1] == ')')//no (,) allowed before &,^
					return 1;
                //'precedence '!'>'&'>'^', but '!'=33,'&'=38,'^'=94 (use tricks)
				while (!operatorstack.empty() && operatorstack.top()!='(' && infix[i] >= operatorstack.top())

				{
					postfix += operatorstack.top();
					operatorstack.pop();
				}
				operatorstack.push(infix[i]);
				break;
			default:
				return 1;
		}
	}
	while (!operatorstack.empty())
	{
		postfix += operatorstack.top();
		operatorstack.pop();
	}

	stack<bool> operandstack;
	for (unsigned int i = 0; i < postfix.size(); i++)
	{
		if (postfix[i] == 'T')
			operandstack.push(true);
		else if (postfix[i] == 'F')
			operandstack.push(false);
		else if (postfix[i] == '!')
		{
			bool operand1 = operandstack.top();
			operandstack.pop();
			operandstack.push(!operand1);
		}
		else 
		{
			bool operand2 = operandstack.top();
			operandstack.pop();
			bool operand1 = operandstack.top();
			operandstack.pop();
			if (postfix[i] == '&')
				operandstack.push(operand1 && operand2);
			if (postfix[i] == '^')
				operandstack.push((operand1 && !operand2) || (!operand1 && operand2));
		}
	}
	if (!operandstack.empty())
		{
			result = operandstack.top();
			operandstack.pop();
			return 0;
		}
	return 1;
}

int main()
{
	string pf;
	bool answer;
	assert(evaluate("T^ F", pf, answer) == 0 && pf == "TF^" && answer);
	assert(evaluate("T^", pf, answer) == 1);
	assert(evaluate("F F", pf, answer) == 1);
	assert(evaluate("TF", pf, answer) == 1);
	assert(evaluate("()", pf, answer) == 1);
	assert(evaluate("()T", pf, answer) == 1);
	assert(evaluate("T(F^T)", pf, answer) == 1);
	assert(evaluate("T(&T)", pf, answer) == 1);
	assert(evaluate("(T&(F^F)", pf, answer) == 1);
	assert(evaluate("T|F", pf, answer) == 1);
	assert(evaluate("", pf, answer) == 1);
	assert(evaluate("F  ^  !F & (T&F) ", pf, answer) == 0
		&& pf == "FF!TF&&^" && !answer);
	assert(evaluate(" F  ", pf, answer) == 0 && pf == "F" && !answer);
	assert(evaluate("((T))", pf, answer) == 0 && pf == "T" && answer);
	cout << "Passed all tests" << endl;
}