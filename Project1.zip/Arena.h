#ifndef ARENA_D
#include <iostream>
#include <string>
#include <random>
#include <utility>
#include <cstdlib>
#include <cctype>
using namespace std;
class Arena;
#define ARENA_D
#endif

#ifndef GLOBALS_H
#include "globals.h"
#define GLOBALS_H
#endif

#ifndef RABBIT_H
#include "Rabbit.h"
#define	RABBIT_H
#endif

#ifndef PLAYER_H
#include "Player.h"
#define	PLAYER_H
#endif

#ifndef GAME_H
#include "Game.h"
#define	GAME_H
#endif

#ifndef HISTORY_H
#include "History.h"
#define HISTORY_H
#endif

#ifndef ARENA_H
class Arena
{
public:
    // Constructor/destructor
    Arena(int nRows, int nCols);
    ~Arena();

    // Accessors
    int     rows() const;
    int     cols() const;
    Player* player() const;
    int     rabbitCount() const;
    int     getCellStatus(int r, int c) const;
    int     numberOfRabbitsAt(int r, int c) const;
    void    display(string msg) const;
    History& history();

    // Mutators
    void setCellStatus(int r, int c, int status);
    bool addRabbit(int r, int c);
    bool addPlayer(int r, int c);
    void moveRabbits();

private:
    int     m_grid[MAXROWS][MAXCOLS];
    int     m_rows;
    int     m_cols;
    Player* m_player;
    Rabbit* m_rabbits[MAXRABBITS];
    int     m_nRabbits;
    int     m_turns;
    History m_history;

    // Helper functions
    void checkPos(int r, int c, string functionName) const;
    bool isPosInBounds(int r, int c) const;
};
#define	ARENA_H
#endif

//implementation

#ifndef RABBIT_C
#include "Rabbit.cpp"
#define	RABBIT_C
#endif

#ifndef PLAYER_C
#include "Player.cpp"
#define	PLAYER_C
#endif

#ifndef HISTORY_C
#include "History.cpp"
#define	HISTORY_C
#endif

#ifndef ARENA_C
#include "Arena.cpp"
#define	ARENA_C
#endif

#ifndef GAME_C
#include "Game.cpp"
#define	GAME_C
#endif

///////////////////////////////////////////////////////
//Auxiliary function implementation////////////////
// ////////////////////////////////////////////////

  // Return a uniformly distributed random int from lowest to highest, inclusive

#ifndef UTILITIES_C
#include "utilities.cpp"
#define	UTILITIES_C
#endif


