
#ifndef ARENA_D
#include <iostream>
#include <string>
#include <random>
#include <utility>
#include <cstdlib>
#include <cctype>
using namespace std;
class Arena;
#define ARENA_D
#endif

#ifndef GLOBALS_H
///////////////////////////////////////////////////////////////////////////
// Manifest constants
///////////////////////////////////////////////////////////////////////////

const int MAXROWS = 20;               // max number of rows in the arena
const int MAXCOLS = 25;               // max number of columns in the arena
const int MAXRABBITS = 100;           // max number of rabbits allowed
const int INITIAL_RABBIT_HEALTH = 2;  // initial rabbit health
const int POISONED_IDLE_TIME = 1;     // poisoned rabbit idles this many turns
                                      //   between moves

const int NORTH = 0;
const int EAST = 1;
const int SOUTH = 2;
const int WEST = 3;
const int NUMDIRS = 4;

const int EMPTY = 0;
const int HAS_POISON = 1;

//prototype declarations
int randInt(int lowest, int highest);

//utilities used in many classes
bool attemptMove(const Arena& a, int dir, int& r, int& c);
void clearScreen();
#define GLOBALS_H
#endif

#ifndef RABBIT_H
#include "Rabbit.h"
#define	RABBIT_H
#endif

#ifndef PLAYER_H
#include "Player.h"
#define	PLAYER_H
#endif

#ifndef ARENA_H
#include "Arena.h"
#define	ARENA_H
#endif

#ifndef GAME_H
#include "Game.h"
#define	GAME_H
#endif

#ifndef HISTORY_H
#include "History.h"
#define HISTORY_H
#endif

//implementation

#ifndef RABBIT_C
#include "Rabbit.cpp"
#define	RABBIT_C
#endif

#ifndef PLAYER_C
#include "Player.cpp"
#define	PLAYER_C
#endif

#ifndef HISTORY_C
#include "History.cpp"
#define	HISTORY_C
#endif

#ifndef ARENA_C
#include "Arena.cpp"
#define	ARENA_C
#endif

#ifndef GAME_C
#include "Game.cpp"
#define	GAME_C
#endif

///////////////////////////////////////////////////////
//Auxiliary function implementation////////////////
// ////////////////////////////////////////////////

  // Return a uniformly distributed random int from lowest to highest, inclusive

#ifndef UTILITIES_C
#include "utilities.cpp"
#define	UTILITIES_C
#endif



