#ifndef ARENA_D
#include <iostream>
#include <string>
#include <random>
#include <utility>
#include <cstdlib>
#include <cctype>
using namespace std;
class Arena;
#define ARENA_D
#endif

#ifndef GLOBALS_H
#include "globals.h"
#define GLOBALS_H
#endif

#ifndef RABBIT_H
#include "Rabbit.h"
#define	RABBIT_H
#endif

#ifndef PLAYER_H

class Player
{
public:
    // Constructor
    Player(Arena* ap, int r, int c);

    // Accessors
    int  row() const;
    int  col() const;
    bool isDead() const;

    // Mutators
    string dropPoisonedCarrot();
    string move(int dir);
    void   setDead();

private:
    Arena* m_arena;
    int    m_row;
    int    m_col;
    bool   m_dead;
};
#define	PLAYER_H
#endif

#ifndef GAME_H
#include "Game.h"
#define	GAME_H
#endif

#ifndef HISTORY_H
#include "History.h"
#define HISTORY_H
#endif

#ifndef ARENA_H
#include "Arena.h"
#define	ARENA_H
#endif
//implementation

#ifndef RABBIT_C
#include "Rabbit.cpp"
#define	RABBIT_C
#endif

#ifndef PLAYER_C
#include "Player.cpp"
#define	PLAYER_C
#endif

#ifndef HISTORY_C
#include "History.cpp"
#define	HISTORY_C
#endif

#ifndef ARENA_C
#include "Arena.cpp"
#define	ARENA_C
#endif

#ifndef GAME_C
#include "Game.cpp"
#define	GAME_C
#endif

///////////////////////////////////////////////////////
//Auxiliary function implementation////////////////
// ////////////////////////////////////////////////

  // Return a uniformly distributed random int from lowest to highest, inclusive

#ifndef UTILITIES_C
#include "utilities.cpp"
#define	UTILITIES_C
#endif


